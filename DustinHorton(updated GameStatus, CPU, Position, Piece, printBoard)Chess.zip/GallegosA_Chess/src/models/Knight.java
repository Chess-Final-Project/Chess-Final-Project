package models;

public class Knight extends Piece {
    @Override
    public int[][] move(int start) {

    }
}
