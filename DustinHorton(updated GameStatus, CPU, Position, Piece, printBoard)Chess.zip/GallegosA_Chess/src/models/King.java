package models;

public class King extends Piece {
    @Override
    public int[][] move(int start) {

    }
}
