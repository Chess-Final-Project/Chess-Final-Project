package models;

public enum GameStatus {
    ACTIVE,
    WHITEWIN,
    BLACKWIN,
    FORFEIT,
    STALEMATE
}
