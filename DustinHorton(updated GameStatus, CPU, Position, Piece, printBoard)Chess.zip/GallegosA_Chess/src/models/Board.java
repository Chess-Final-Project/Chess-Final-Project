package models;

public class Board {
    public final int ROWS = 8;
    public final int COLS = 8;
    private Position[][] grid;
    private Piece piece;


    public Board() {
        this.reset();
    }

    public Position getGridSpot(int row, int col) {
        if(row < 0 || row > 7 || col < 0 || col > 7) {
            try {
                throw new Exception("Index out of bounds.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return grid[row][col];
    }

    public boolean isPieceAt(int row, int col) {
        return grid[row][col] != null;
    }

    public boolean movePiece(Position start, Position end) {
        //boolean isgood = false;
        Piece


        //return isgood;
    }

    public boolean isMoveLegal(int[][] move) {
        return false;
    }

    public void checkWin(Piece[][] grid) {

    }

    public void checkMate(Piece[][] grid) {

    }

    public void staleMate(Piece[][] grid) {

    }

    public String reset() {
        Rook rook = new Rook();
        Knight knight = new Knight();
        Bishop bishop = new Bishop();
        Queen queen = new Queen();
        King king = new King();
        Pawn pawn = new Pawn();
        //White set up
        grid[0][0] = new Position(rook, 0,0);
        grid[0][1] = new Position(knight, 0,1);
        grid[0][2] = new Position(bishop, 0,2);
        grid[0][3] = new Position(queen, 0,3);
        grid[0][4] = new Position(king, 0,4);
        grid[0][5] = new Position(bishop, 0,5);
        grid[0][6] = new Position(knight, 0,6);
        grid[0][7] = new Position(rook, 0, 7);
        for(int i = 0; i < 8; i++) {
            grid[1][i] = new Position(pawn,1, i);
        }

        //Black set up
        grid[7][0] = new Position(rook, 7, 0);
        grid[7][1] = new Position(knight, 7,1);
        grid[7][2] = new Position(bishop, 7,2);
        grid[7][3] = new Position(queen, 7, 3);
        grid[7][4] = new Position(king, 7, 4);
        grid[7][5] = new Position(bishop, 7,5);
        grid[7][6] = new Position(knight, 7, 6);
        grid[7][7] = new Position(rook, 7, 7);
        for(int i = 0; i < 8; i++) {
            grid[6][i] = new Position(pawn, 6, 0);
        }

        for(int i = 2; i < 5; i++) {
            for(int j = 0; j < 8; j++) {
                grid[i][j] = null;
            }
        }
        String print = grid.toString();
        return print;
    }


    @Override
    public String toString() {

        return reset();
    }
}
