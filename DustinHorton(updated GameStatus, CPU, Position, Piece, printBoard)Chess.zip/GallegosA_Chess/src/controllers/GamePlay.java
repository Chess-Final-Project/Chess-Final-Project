package controllers;

import models.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GamePlay {
    private static Piece piece;
    private static Board board;
    private static GameStatus status;
    private static Player player;

    private static BufferedReader buffy;

    public static void run() {
        String input = promptForString("Enter your name: ");
        int num = promptForMenuSelection( , true);


    }

    public void setStatus(GameStatus status)
    {
        this.status = status;
    }

    public GameStatus getStatus()
    {
        return this.status;
    }

    private static void printBoard() {
        Board.Board();

    }

    public static String promptForString (String prompt){
        if (prompt != null && !prompt.trim().isEmpty()) {
            String input = null;
            boolean isInvalid = true;

            do {
                System.out.print(prompt);

                try {
                    input = buffy.readLine();
                    isInvalid = input == null || input.trim().isEmpty();
                    if (isInvalid) {
                        System.out.println("Your input cannot be null, empty, or just white space. Please, try again.");
                    }
                } catch (IOException var4) {
                    System.out.println("There was a technical issue. Please, try again.");
                }
            } while (isInvalid);

            return input;
        } else {
            throw new IllegalArgumentException("The prompt cannot be null, empty, or whitespace-only");
        }
    }

    public static int promptForInt (String prompt, int min, int max){
        if (max < min) {
            throw new IllegalArgumentException("The min cannot be greater than the max.");
        } else {
            int userNum = 0;
            boolean isInvalid = true;

            do {
                String input = promptForString(prompt);

                try {
                    userNum = Integer.parseInt(input);
                    isInvalid = userNum < min || userNum > max;
                } catch (NumberFormatException var) {
                }

                if (isInvalid) {
                    System.out.println("You must enter a number between " + min + " and " + max + ". Please, try again.");
                }
            } while (isInvalid);

            return userNum;
        }
    }
    public static int promptForMenuSelection (String[]options,boolean withQuit){
        if (options.length == 0 && !withQuit) {
        }

        if ((options == null || options.length == 0) && withQuit) {
            throw new IllegalArgumentException("There must be at least one menu option to select.");
        } else {
            StringBuilder sb = new StringBuilder("Please, choose one of the following: \n\n");

            for (int i = 0; i < options.length; ++i) {
                sb.append(i + 1).append(") ").append(options[i]);
            }

            if (options.length > 0) {
                sb.append("\n");
            }

            if (withQuit) {
                sb.append("0) Quit\n");
            }

            sb.append("Enter the number of your selection: ");
            String menuString = sb.toString();
            int min = withQuit ? 0 : 1;
            int max = options.length;
            int userInput = promptForInt(menuString, min, max);
            return userInput;
        }
    }

    static {
        buffy = new BufferedReader(new InputStreamReader(System.in));
    }

}
