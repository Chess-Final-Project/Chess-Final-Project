package controllers;

import models.Board;
import models.Piece;
import models.Player;

public class GamePlay {
    private static Piece piece;
    private static Board board;
    private static Player player;

    public static void run() {

    }

    private static int mainMenu() {

    }

    private static void printBoard() {
        
    }
}
