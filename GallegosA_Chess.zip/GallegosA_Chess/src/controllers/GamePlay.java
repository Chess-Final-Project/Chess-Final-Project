package controllers;

import lib.ConsoleIO;
import models.Board;
import models.Piece;
import models.Player;

import java.util.Random;

public class GamePlay {
    private static Piece piece;
    private static Board board;
    private static Player player;

    public static void run() {

    }


    private static int mainMenu() {
//        ConsoleIO.promptForMenuSelection()
        return 0;
    }

    private static void printBoard() {
        
    }
}
