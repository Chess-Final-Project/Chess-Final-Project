package models;

public class King extends Piece {
    Position spot;

    @Override
    public int[][] move(Position start) {
        if (start.getRows() - spot.getRows() <= 1 &&
                start.getCols() - spot.getCols() <= 1) {
            return checkDiagonal() && checkHorizontal() & checkVertical();
        }
        return move(start);
    }
}
