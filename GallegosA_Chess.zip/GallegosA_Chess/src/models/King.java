package models;

public class King extends Piece {
    Position spot;

    @Override
    public boolean move(Position start) {
        if (start.getRows() - spot.getRows() <= 1 &&
                start.getCols() - spot.getCols() <= 1) {
            return checkDiagonal(start, spot) && checkHorizontal(start, spot) & checkVertical(start, spot);
        }
        return move(start);
    }
}
