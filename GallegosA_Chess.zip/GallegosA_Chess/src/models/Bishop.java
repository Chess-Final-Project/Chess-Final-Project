package models;

public class Bishop extends Piece {
    Position spot;
    @Override
    public int[][] move(Position start) {
        if (start.getRows() - spot.getRows() ==
            start.getCols() - spot.getCols()){
          return checkDiagonal();
        }
        return move(start);
    }

}
