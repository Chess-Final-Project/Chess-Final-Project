package models;

public class Bishop extends Piece {
    Position spot;
    @Override
    public boolean move(Position start) {
        if (start.getRows() - spot.getRows() ==
            start.getCols() - spot.getCols()){
          return checkDiagonal(start ,spot);
        }
        return move(start);
    }

}
