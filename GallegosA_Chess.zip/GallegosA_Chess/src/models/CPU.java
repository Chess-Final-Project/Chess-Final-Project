package models;

import java.util.Random;

public class CPU extends Player{
    public void randMove(int[][] place) {
        Random rng = new Random();
        CPU.super.getPiece();
//        place = CPU.super.getPiece().move(rng.nextInt());
    }
}
