package models;

public class Pawn extends Piece {
    Position spot;
    private boolean firstMove;
    private int one;

    @Override
    public int[][] move(Position start) {
        if (start.getCols() == spot.getCols()) {
            if ((start.getRows() - spot.getRows() == one)) {
                if (firstMove) {
                    firstMove = false;
                }

            } else if (firstMove && (start.getRows() - spot.getRows() == (one * 2))) {
                if (firstMove) {
                    firstMove = false;
                }
                return move(start);
            }
        }
        return move(start);
    }
}

