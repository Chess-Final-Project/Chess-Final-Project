package models;

public class Pawn extends Piece{

//    public Pawn(Board board) {
//        super(board);
//    }

    @Override
    public int[][] move(Position start) {
        int[][] some = {{2,3}, {4,2}};
        return some;
    }
}
