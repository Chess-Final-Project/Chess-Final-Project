package models;

public abstract class Piece {
    private Board board;
    private Color color;

    public Piece() {
    }

    public Piece(Color color) {
        this.setColor(color);
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    //    public Piece(Board board) {
//        this.board = board;
//    }

    public Board getBoard() {
        return board;
    }

    public boolean checkVertical(Position start, Position end) {

        if(start.getCols() == end.getCols()) {
            int one = (start.getRows() - end.getRows()< 0) ? 1: -1;
            for(int row = start.getRows() + one; row < end.getRows(); row += one) {
                if(board.isPieceAt(row, start.getCols())) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public boolean checkHorizontal(Position start, Position end) {
        if(start.getRows() == end.getRows()) {
            int one = (start.getRows() - end.getRows() < 0) ? 1 : -1;
            for(int col = start.getCols() + one; col < end.getCols(); col += one) {
                if(board.isPieceAt(start.getRows(), col)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public boolean checkDiagonal(Position start, Position end) {
        int one = (start.getRows() - end.getRows() < 0) ? 1 : -1;
        if(start.getCols() - end.getCols() == start.getRows() - end.getRows()) {

            for(int i = one; Math.abs(i) < Math.abs(start.getRows() - end.getRows()); i += one) {
                if(board.isPieceAt(start.getRows() + i, start.getCols() + i)) {
                    return false;
                }
            }
            return true;
        }
        else if(start.getCols() - end.getCols() * -1 == start.getRows() - end.getCols()) {
            int negOne = one * -1;
            for(int i = one; Math.abs(i) < Math.abs(start.getRows() - end.getRows()); i += one) {
                if(board.isPieceAt(start.getRows() + i, start.getCols() + (i * negOne))){
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    abstract public int[][] move(Position start);
}
