package models;

public class Queen extends Piece {
    Position spot;

    @Override
    public boolean move(Position start) {
        if (start.getRows() - spot.getRows() == start.getCols() - spot.getCols()
                && (start.getRows() == spot.getRows()) != (start.getCols() == spot.getCols())){
            return checkDiagonal(start, spot) && checkHorizontal(start, spot) && checkVertical(start, spot);
        }
        return move(start);
    }

    @Override
    public String toString() {
        return "Q";
    }
}
