package models;

public class Queen extends Piece {
    @Override
    public int[][] move(Position start) {
        int[][] some = {{2,3}, {4,2}};
        return some;
    }
}
