package models;

public class Knight extends Piece {
    Position spot;

    @Override
    public boolean move(Position start) {
        if(start.getRows() - spot.getRows() == 2 &&
        start.getCols() - spot.getCols() ==1){

            return move(start);
        }else  if (start.getRows() - spot.getRows() == 1 &&
        start.getCols() - spot.getRows() == 2){
            return move(start);
        }
        return move(start);
    }
}
