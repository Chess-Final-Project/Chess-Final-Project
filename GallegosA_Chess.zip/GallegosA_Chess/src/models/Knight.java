package models;

public class Knight extends Piece {
    @Override
    public int[][] move(Position start) {

    }
}
