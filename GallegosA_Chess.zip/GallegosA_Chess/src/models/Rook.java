package models;

public class Rook extends Piece{
    @Override
    public int[][] move(int place) {
        return super.move(place);
    }
}
