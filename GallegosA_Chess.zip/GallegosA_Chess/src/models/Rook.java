package models;

public class Rook extends Piece{
    @Override
    public int[][] move(Position start) {

    }
}
