package models;

public class Rook extends Piece{
    Position spot;
    @Override
    public int[][] move(Position start) {
        if(start.getRows() == spot.getRows()) !=
        (start.getCols() == spot.getCols()) {

            return  checkHorizontal() && checkVertical();

        }
    }
}
