package models;

public class Board {
    public final int ROWS = 9;
    public final int COLS = 9;
    private Piece[][] grid;

    public Piece[][] getGrid() {
        return grid;
    }

    public boolean movePiece(int[][] place) {

        return false;
    }

    public boolean isMoveLegal(int[][] move) {

        return false;
    }

    public void checkWin(Piece[][] grid) {

    }

    public void checkMate(Piece[][] grid) {

    }

    public void staleMate(Piece[][] grid) {

    }

    @Override
    public String toString() {
        return "Board{}";
    }
}
