package models;

public class King extends Piece {
    @Override
    public int[][] move(Position start) {
        int[][] some = {{2,3}, {4,2}};
        return some;
    }

    @Override
    public String toString() {
        return "K";
    }
}
