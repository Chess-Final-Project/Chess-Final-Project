package models;

public class Player {
    private Color color;
    private Piece piece;

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Piece getPiece() {
        return piece;
    }
}
