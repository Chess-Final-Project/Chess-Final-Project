package models;

public class Board {
//    public final int ROWS = 8;
//    public final int COLS = 8;
    private Piece[][] grid;
    private Piece piece;


    public Board() {
        grid = new Piece[8][8];
    }

    public Piece getGridSpot(int row, int col) {
        if(row < 0 || row > 7 || col < 0 || col > 7) {
            try {
                throw new Exception("Index out of bounds.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return grid[row][col];
    }

    public boolean isPieceAt(int row, int col) {
        return grid[row][col] != null;
    }

    public void movePiece(Piece piece, Position end) {
        if(isPieceAt(end.getRows(),end.getCols())) {
            removePiece(end);
        }
        
    }

    public void removePiece(Position position) {
        grid[position.getRows()][position.getCols()] = null;
    }

    public Piece getPieceAt(Position position) {
        return grid[position.getRows()][position.getCols()];
    }

    public boolean isMoveLegal(int[][] move) {
        return false;
    }

    public void checkWin(Piece[][] grid) {

    }

    public void checkMate(Piece[][] grid) {

    }

    public void staleMate(Piece[][] grid) {

    }

    public String reset() {
        Rook rook = new Rook();
        Knight knight = new Knight();
        Bishop bishop = new Bishop();
        Queen queen = new Queen();
        King king = new King();
        Pawn pawn = new Pawn();
        //White set up
        grid[0][0] = rook;
        grid[0][1] = knight;
        grid[0][2] = bishop;
        grid[0][3] = queen;
        grid[0][4] = king;
        grid[0][5] = bishop;
        grid[0][6] = knight;
        grid[0][7] = rook;
        for(int i = 0; i < 8; i++) {
            grid[1][i] = pawn;
        }
//
//        //Black set up
        grid[7][0] = rook;
        grid[7][1] = knight;
        grid[7][2] = bishop;
        grid[7][3] = queen;
        grid[7][4] = king;
        grid[7][5] = bishop;
        grid[7][6] = knight;
        grid[7][7] = rook;
        for(int i = 0; i < 8; i++) {
            grid[6][i] = pawn;
        }

        for(int i = 2; i < 5; i++) {
            for(int j = 0; j < 8; j++) {
                grid[i][j] = null;
            }
        }
        String print = grid.toString();
        return print;
    }


    @Override
    public String toString() {
        String s = "  0  1  2  3  4  5  6  7\n";
        for(int row = 0; row < 8; row++) {
            s += row;
            for(int col = 0; col < 8; col++) {
                if(grid[row][col] != null) {
                    s += " " + grid[row][col] + " ";
                }
                else {
                    s += " - ";
                }
            }
            s += "\n";
        }
        return s;
    }
}
