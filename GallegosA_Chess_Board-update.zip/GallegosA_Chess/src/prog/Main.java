package prog;

import controllers.GamePlay;

public class Main {

    public static void main(String[] args) {
        GamePlay.run();
    }
}
