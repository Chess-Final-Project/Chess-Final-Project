package controllers;

import lib.ConsoleIO;
import models.*;

import java.util.Random;

public class GamePlay {
    private static Piece piece;
    private static Board board = new Board();
    private static Player player;
    private static Rook rook = new Rook();
   private static Knight knight = new Knight();
    private static Bishop bishop = new Bishop();
    private static Queen queen = new Queen();
    private static King king = new King();
    private static Pawn pawn = new Pawn();

    public static void run() {

        reset();
        System.out.println(board.toString());
        System.out.println(knight.move(new Position(2,3)));

//        board.removePiece(new Position(1,0));
//        update(pawn, new Position(3,0));
//        System.out.println(board.toString());
//        update(rook, new Position(6,7));
//        System.out.println(board.toString());

    }

    public static void update(Piece piece, Position position) {
        if(board.isPieceAt(position.getRows(), position.getCols())) {
            board.removePiece(position);
        }
        if(piece.getSpot() != null) {
            board.removePiece(piece.getSpot());
        }
        board.getGrid()[position.getRows()][position.getCols()] = piece;
        piece.setSpot(position);
    }

    public static String reset() {
//        Rook rook = new Rook();
//        Knight knight = new Knight();
//        Bishop bishop = new Bishop();
//        Queen queen = new Queen();
//        King king = new King();
//        Pawn pawn = new Pawn();
        //White set up
        board.getGrid()[0][0] = rook;
        board.getGrid()[0][1] = knight;
        board.getGrid()[0][2] = bishop;
        board.getGrid()[0][3] = queen;
        board.getGrid()[0][4] = king;
        board.getGrid()[0][5] = bishop;
        board.getGrid()[0][6] = knight;
        board.getGrid()[0][7] = rook;
        for(int i = 0; i < 8; i++) {
            board.getGrid()[1][i] = pawn;
        }
//
//        //Black set up
        board.getGrid()[7][0] = rook;
        board.getGrid()[7][1] = knight;
        board.getGrid()[7][2] = bishop;
        board.getGrid()[7][3] = queen;
        board.getGrid()[7][4] = king;
        board.getGrid()[7][5] = bishop;
        board.getGrid()[7][6] = knight;
        board.getGrid()[7][7] = rook;
        for(int i = 0; i < 8; i++) {
            board.getGrid()[6][i] = pawn;
        }

        for(int i = 2; i < 5; i++) {
            for(int j = 0; j < 8; j++) {
                board.getGrid()[i][j] = null;
            }
        }
        String print = board.getGrid().toString();
        return print;
    }

    private static int mainMenu() {
//        ConsoleIO.promptForMenuSelection()
        return 0;
    }

    private static void printBoard() {
        
    }
}
