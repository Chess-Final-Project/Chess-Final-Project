package models;

public class King extends Piece {
    @Override
    public boolean move(Position start) {
        if (start.getRows() - super.getSpot().getRows() <= 1 &&
                start.getCols() - super.getSpot().getCols() <= 1) {
            return checkDiagonal(start, super.getSpot()) && checkHorizontal(start, super.getSpot()) & checkVertical(start, super.getSpot());
        }
        return move(start);
    }

    @Override
    public String toString() {
        return "K";
    }
}
