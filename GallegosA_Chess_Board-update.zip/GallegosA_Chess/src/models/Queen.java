package models;

public class Queen extends Piece {
    @Override
    public boolean move(Position start) {
        if (start.getRows() - super.getSpot().getRows() == start.getCols() - super.getSpot().getCols()
                && (start.getRows() == super.getSpot().getRows()) != (start.getCols() == super.getSpot().getCols())){
            return checkDiagonal(start, super.getSpot()) && checkHorizontal(start, super.getSpot()) && checkVertical(start, super.getSpot());
        }
        return move(start);
    }

    @Override
    public String toString() {
        return "Q";
    }
}
