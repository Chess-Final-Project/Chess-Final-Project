package models;

public class Pawn extends Piece{

    private boolean firstMove;
    private int one;
//    public Pawn(Board board) {
//        super(board);
//    }

    @Override
    public boolean move(Position start) {
//        boolean firstMove;
//        int one;
        if (start.getCols() == super.getSpot().getCols()) {
            if ((start.getRows() - super.getSpot().getRows() == one)) {
                if (firstMove) {
                    firstMove = false;
                }

            } else if (firstMove && (start.getRows() - super.getSpot().getRows() == (one * 2))) {
                if (firstMove) {
                    firstMove = false;
                }
                return !super.getBoard().isPieceAt(start.getRows(), start.getCols()) && super.move(start);
            }
        }
        else if (Math.abs(start.getCols() - super.getSpot().getCols()) == 1) {
            if(super.getBoard().isPieceAt(start.getRows(),start.getCols()) &&
            start.getRows() - super.getSpot().getRows() == one) {

                if (firstMove) {
                    firstMove = false;
                }
                return super.move(start);
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "P";
    }
}
