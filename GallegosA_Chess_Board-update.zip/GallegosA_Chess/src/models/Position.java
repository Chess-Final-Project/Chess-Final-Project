package models;

public class Position {
    private Piece piece;
    private int Rows;
    private int Cols;

    public Position(int rows, int cols) {
//        this.setPiece(piece);
        this.setRows(rows);
        this.setCols(cols);
    }

    public Piece getPiece() {
        return piece;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }

    public int getRows() {
        return Rows;
    }

    public void setRows(int rows) {
        Rows = rows;
    }

    public int getCols() {
        return Cols;
    }

    public void setCols(int cols) {
        Cols = cols;
    }
}
