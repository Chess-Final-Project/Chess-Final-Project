package models;

public class Board {
//    public final int ROWS = 8;
//    public final int COLS = 8;
    private Piece[][] grid;
    private Piece piece;


    public Board() {
        grid = new Piece[8][8];
    }

    public Piece[][] getGrid() {
        return grid;
    }

    public Piece getGridSpot(int row, int col) {
        if(row < 0 || row > 7 || col < 0 || col > 7) {
            try {
                throw new Exception("Index out of bounds.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return grid[row][col];
    }

    public boolean isPieceAt(int row, int col) {
        return grid[row][col] != null;
    }

    public void placePieceAT(Piece piece, Position position) {
        if(isPieceAt(position.getRows(), position.getCols())) {
            removePiece(position);
        }
        if(piece.getSpot() != null) {
            removePiece(piece.getSpot());
        }
        grid[position.getRows()][position.getCols()] = piece;
        piece.setSpot(position);
    }

    public void removePiece(Position position) {
        grid[position.getRows()][position.getCols()] = null;
    }

    public Piece getPieceAt(Position position) {
        return grid[position.getRows()][position.getCols()];
    }

    public boolean isMoveLegal(Piece piece, Position spot) {
        return piece.move(spot);
    }

    public boolean checkMate() {
        boolean checkMate = false;
        King fresh = new King();
        for(int row = 0; row < 8; row++) {
            for(int col = 0; col < 8; col++) {


            }
        }
        return checkMate;
    }

    public void staleMate(Piece[][] grid) {

    }


    @Override
    public String toString() {
        String s = "  0  1  2  3  4  5  6  7\n";
        for(int row = 0; row < 8; row++) {
            s += row;
            for(int col = 0; col < 8; col++) {
                if(grid[row][col] != null) {
                    s += " " + grid[row][col] + " ";
                }
                else {
                    s += " - ";
                }
            }
            s += "\n";
        }
        return s;
    }
}
