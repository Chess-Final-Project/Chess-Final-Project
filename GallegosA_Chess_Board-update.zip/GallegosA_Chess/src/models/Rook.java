package models;

public class Rook extends Piece{
    @Override
    public boolean move(Position start) {
        if ((start.getRows() == super.getSpot().getRows()) !=
                (start.getCols() == super.getSpot().getCols())){

            return checkHorizontal(start, super.getSpot()) && checkVertical(start, super.getSpot());
        }
        return move(start);
    }

    @Override
    public String toString() {
        return "R";
    }
}
