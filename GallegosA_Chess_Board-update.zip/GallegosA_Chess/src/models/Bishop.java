package models;

public class Bishop extends Piece {

    @Override
    public boolean move(Position start) {
        if (start.getRows() - super.getSpot().getRows() ==
                start.getCols() - super.getSpot().getCols()){
            return checkDiagonal(start ,super.getSpot());
        }
        return move(start);
    }

    @Override
    public String toString() {
        return "B";
    }
}
